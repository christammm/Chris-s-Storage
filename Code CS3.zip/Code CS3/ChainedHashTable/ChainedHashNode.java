
public class ChainedHashNode
{
   Object element;
   Object key;
   ChainedHashNode link;
}
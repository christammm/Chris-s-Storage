public class Algorithms
{
    public static void selectionSort(int [] data, int first, int n)
    {
        for(int i = n-1; i > 0; i--)
        {
    }
    
    public static void insertionSort(int [] data, int first, int n)
    {
        
    }
    
    public static void mergeSort(int [] data, int first, int n)
    {
        
    }
    
    public static void quickSort(int [] data, int first, int n)
    {
        
    }
    
    public static void heapSort(int [] data, int first, int n)
    {
        
    }
}
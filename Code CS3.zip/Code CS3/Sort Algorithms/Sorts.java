// File: Sorts.java
// A Java application to illustrate the several methods for sorting an array.
// Additional javadoc documentation is available at:
//   http://www.cs.colorado.edu/~main/docs/Sorts.html

import java.util.*;

/******************************************************************************
 * The <CODE>Sorts</CODE> Java application allows the user to run several
 * different methods for sorting an array.
 *
 * <p><dt><b>Java Source Code for this class:</b><dd>
 *   <A HREF="../applications/Sorts.java">
 *   http://www.cs.colorado.edu/~main/applications/SimpleSearcher.java
 *   </A>
 *
 * @author Michael Main
 *   <A HREF="mailto:main@colorado.edu"> (main@colorado.edu) </A>
 *
 * @version
 *   Jun 12, 1998
 ******************************************************************************/
public class Sorts
{
    /**
     * The main method allows the user to run several different
     * methods for sorting an array of integers.
     * The <CODE>String</CODE> arguments (<CODE>args</CODE>) are not used
     * in this implementation.
     **/
    private static int sortCount = 0;
    private static int insertCount = 0;
    private static int mergeCount = 0;
    private static int quickCount = 0;
    private static int heapCount = 0;
    private static double nLogN = 0;
    private static int[] N = {1000, 2000, 3000, 4000 , 5000 , 6000, 7000, 8000, 9000, 10000};
    private static double[] data = new double[10]; 
    public static void main(String[ ] args)
    {
        final char BLANK = ' ';
        final int ARRAY_SIZE = 1000;

        Random kb = new Random(0);

        long [ ] data = new long[5];
        int[ ] userArray = new int[ARRAY_SIZE]; // Array typed by the user
        int userInput;                          // Number typed by the user
        int numberOfElements;                   // How much of the array is used
        int i = 0;                              // Array index
        int count = 0;
        int[ ] sort;   
        int[ ] insert;   
        int[ ] merge;   
        int[ ] quick;   
        int[ ] heap;
      
        // Provide some instructions
        System.out.println("Please type up to " + ARRAY_SIZE + " integers.");
        System.out.println("Indicate the list's end with a zero.");

        // Read the input numbers
        numberOfElements = 0;
        userInput = kb.nextInt(10000)+2;
        while ((userInput != 0) && (numberOfElements < ARRAY_SIZE))
        {
            userArray[numberOfElements] = userInput;
            numberOfElements++;
            userInput = kb.nextInt(10000)+2;
        }
        // Sort the numbers several ways and print the result each time

        System.out.println("---------------------------------------------------------------------");
        System.out.println("  N    selectionsort insertionsort mergesort quicksort heapsort NlogN");
        System.out.println("---------------------------------------------------------------------");
        System.out.print("  " + userArray.length + "   ");

        // SELECTION SORT
        //System.out.println("Result before sorting");
        //for(int j = 0; j < userArray.length; j++){
        //    System.out.println(userArray[j]);
        //}

        sort = userArray.clone();
        //         long begin = System.currentTimeMillis();
        selectionSort(sort, 0, numberOfElements);
        //         long end = System.currentTimeMillis();
        //         data[0] = (end - begin);
        //         System.out.println("Result of selection sort:");
        //for(int j = 0; j < sort.length; j++){
        //    System.out.println(sort[j]);
        //}
        // INSERTION SORT

        insert = userArray.clone();
        //         begin = System.currentTimeMillis();
        //         for(int j = 0; j < insert.length; j++){
        //             System.out.println(insert[j]);
        //         }

        insertionSort(insert, 0, numberOfElements);
        //         end = System.currentTimeMillis();
        //         data[1] = (end - begin);
        //         System.out.println("Result of insertion sort:");
        //         for(int j = 0; j < insert.length; j++){
        //             System.out.println(insert[j]);
        //         }

        // MERGE SORT

        merge = userArray.clone();
        //         begin = System.currentTimeMillis();
        //         for(int j = 0; j < merge.length; j++){
        //             System.out.println(merge[j]);
        //         }
        mergeSort(merge, 0, numberOfElements-1);
        //         end = System.currentTimeMillis();
        //         data[2] = (end - begin);
        //         System.out.println("Result of merge sort:");
        //         for(int j = 0; j < merge.length; j++){
        //             System.out.println(merge[j]);
        //         }

        // QUICK SORT

        quick = userArray.clone();
        //         begin = System.currentTimeMillis();
        //         for(int j = 0; j < quick.length; j++){
        //             System.out.println(quick[j]);
        //         }
        quickSort(quick, 0, numberOfElements);
        //         end = System.currentTimeMillis();
        //         data[3] = (end - begin);
        //         System.out.println("Result of quick sort:");
        //         for(int j = 0; j < quick.length; j++){
        //             System.out.println(quick[j]);
        //         }

        // HEAP SORT

        heap = userArray.clone();
        //         begin = System.currentTimeMillis();
        //         for(int j = 0; j < heap.length; j++){
        //             System.out.println(heap[j]);
        //         }
        heapSort(heap, numberOfElements);
        //         end = System.currentTimeMillis();
        //         data[4] = (end - begin);
        //         System.out.println("Result of heap sort:");
        //         for(int j = 0; j < heap.length; j++){
        //             System.out.println(heap[j]);
        //         }

        // This will display the time that it takes for each sorting operation that is run.
        //         for(int j = 0; j < data.length; j++)
        //         {
        //             System.out.println(data[j]);
        //         }
    }
    //---------------------------------------------------------------------------------------------------------------------------------
    public static void selectionSort(int[] data, int first, int n)
    {
        int count = 0;
        for(int i = n - 1; i > 0; i--)
        {
            int big = first;
            sortCount++;
            for(int j = first + 1; j <= first + i; j++)
            {
                if(data[j] > data[big])
                {
                    big = j;
                }
            }
            int temp = data[first+i];
            data[first+i] = data[big];
            data[big] = temp;
        }
        System.out.print(sortCount + " ");
    }
    //---------------------------------------------------------------------------------------------------------------------------------
    public static void insertionSort(int[] data, int first, int n)
    {
        for(int i = 1; i < n; i++)
        {
            int entry = data[first + i];
            int j;
            for(j = first + i;( j > first) && (data[j-1] > entry); j--)
            {
                data[j] = data[j-1];
            }
        }
    }
    //---------------------------------------------------------------------------------------------------------------------------------
    public static void mergeSort(int[] data, int first, int n)
    {
        if(n > 1)
        {
            int n1 = n/2;
            int n2 = n - n1;
            mergeSort(data, first, n1);
            mergeSort(data, first + n1, n2);
            merge(data, first, n1, n2);
        }
    }

    public static void merge(int[] data, int first, int n1, int n2)
    {
        int[] temp = new int[n1 + n2];
        int copied = 0, copied1 = 0, copied2 = 0;
        while((copied1 < n1)&&(copied2 < n2))
        {
            if(data[first + copied1] < data[first + n1 + copied2])
            {
                temp[copied++] = data[first+(copied1++)];
                mergeCount++;
            }
            else
            {
                temp[copied++] = data[first+n1+(copied2++)];
                mergeCount++;
            }
        }
        while(copied1 < n1)
        {
            temp[copied++] = data[first+(copied1++)];
            mergeCount++;
        }
        while(copied2 < n2)
        {
            temp[copied++] = data[first+n1+(copied2++)];
            mergeCount++;
        }
        for(int i = 0; i < n1+n2; i++)
        {
            data[first+i] = temp[i];
        }
        System.out.print(" " + mergeCount + " ");
    }
    //---------------------------------------------------------------------------------------------------------------------------------
    public static void quickSort(int[] data, int first, int n)
    {
        if(n>1)
        {
            quickCount++;
            int pivotIndex = partition(data, first, n);
            int n1 = pivotIndex-first;
            int n2 = n-n1-1;
            quickSort(data, first, n1);
            quickSort(data, pivotIndex+1, n2);
        }
    }

    public static void swapQuick(int[] data, int first, int n)
    {
        int temp = data[first];
        data[first] = data[n];
        data[n] = temp;
    }

    private static int partition(int[] data, int first, int n)
    {
        int pivot = data[first];
        while(first < 1)
        {
            quickCount++;
            if(data[first] == pivot || data[n] == pivot)
            {
                System.out.println("Error");
            }
            while(data[first] < pivot)
            {
                first++;
                quickCount++;
            }
            while(data[n] > n)
            {
                n--;
                quickCount++;
            }
            swapQuick(data, first, n);
        }
        System.out.print(" " + quickCount + " ");
        return first;
    }
    //---------------------------------------------------------------------------------------------------------------------------------
    public static void heapSort(int[] data, int n)
    {
        makeHeap(data, n);
        int unsorted = n;
        int count = 0;
        while(n > 1)
        {
            heapCount++;
            unsorted--;
            swapHeap(data, n, unsorted);
            reHeapify(data, unsorted);
        }
    }

    private static void makeHeap(int[] data, int n)
    {
        for(int i = n/2; i >= 0; i--)
        {
            reHeapify(data, i);
        }
    }

    private static void reHeapify(int[] data, int n)
    {
        int n1 = 2*n;
        int n2 = 2*n+1;
        int largest = 0;
        int count = 0;
        if((n1 <= n) && (data[n1] > data[n]))
        {
            largest = n1;
            count++;
        }
        else
        {
            largest = n;
            count++;
        }
        if((n2 <= n) && (data[n2] > data[largest]))
        {
            largest = n2;
            count++;
        }
        if(largest!=n)
        {
            swapHeap(data, n, largest);
            reHeapify(data, largest);
        }
        System.out.println(count);
    }

    public static void swapHeap(int[] data, int n, int largest)
    {
        int temp = data[n];
        data[n] = data[largest];
        data[largest] = temp;
    }
    //---------------------------------------------------------------------------------------------------------------------------------
}